<script lang="ts">
  import { tick } from 'svelte'
  import { DEFAULT_STYLE, type NormalizationMode } from '../../types/project'
  import { COLOR_PALETTES } from './workbenchUtils'

  export let open: boolean
  export let dataset: any | null
  export let datasetCount: number
  export let onClose: () => void
  export let onRename: (datasetId: string, label: string) => void
  export let onUpdateStyle: (datasetId: string, patch: Record<string, unknown>) => void
  export let onUpdateMetadata: (datasetId: string, patch: Record<string, unknown>) => void
  export let onRerunPipeline: (datasetId: string) => void
  export let onTransformEnabled: (datasetId: string, transformId: string, enabled: boolean) => void
  export let onTransformScope: (
    datasetId: string,
    transformId: string,
    scope: 'no' | 'individual' | 'global',
  ) => void
  export let onTransformParam: (
    datasetId: string,
    transformId: string,
    params: Record<string, number | string | boolean>,
    currentScope: 'no' | 'individual' | 'global',
  ) => void
  export let onApplyPalette: (paletteId: string) => void
  export let onApplyLineWidth: (width: number) => void
  export let onApplyNormalization: (mode: NormalizationMode) => void
  export let onApplySmoothing: (windowLength: number, polyorder: number) => void

  let editingTitle = false
  let titleDraft = ''
  let titleInputEl: HTMLInputElement | null = null
  let rightPanelSection: 'general' | 'style' | 'pipeline' | null = 'general'

  let generalPaletteId = COLOR_PALETTES[0].id
  let generalLineWidth = DEFAULT_STYLE.lineWidth
  let generalNormalizationMode: NormalizationMode = 'minmax'
  let generalSmoothingWindow = 15
  let generalSmoothingPolyorder = 2

  $: if (dataset && !editingTitle) {
    titleDraft = dataset.style.label
  }
  $: activeGeneralPalette = COLOR_PALETTES.find((palette) => palette.id === generalPaletteId) ?? COLOR_PALETTES[0]

  async function startTitleEdit(): Promise<void> {
    if (!dataset) return
    editingTitle = true
    titleDraft = dataset.style.label
    await tick()
    titleInputEl?.focus()
    titleInputEl?.select()
  }

  function commitTitleEdit(): void {
    if (!dataset) {
      editingTitle = false
      return
    }
    const trimmed = titleDraft.trim()
    if (trimmed.length > 0 && trimmed !== dataset.style.label) {
      onRename(dataset.id, trimmed)
    }
    editingTitle = false
  }

  function cancelTitleEdit(): void {
    editingTitle = false
    if (dataset) titleDraft = dataset.style.label
  }

  function handleTitleKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      event.preventDefault()
      commitTitleEdit()
    }
    if (event.key === 'Escape') {
      event.preventDefault()
      cancelTitleEdit()
    }
  }
</script>

<aside class="right-sidebar" class:hidden={!open}>
  <div class="panel-header">
    <h2>{dataset ? 'Sample Settings' : 'General Settings'}</h2>
    <button type="button" class="panel-close" aria-label="Close settings panel" on:click={onClose}>
      x
    </button>
  </div>

  {#if dataset}
    <section class="sample-settings">
      <header class="sample-settings-header">
        {#if editingTitle}
          <input
            bind:this={titleInputEl}
            class="sample-title-input"
            type="text"
            bind:value={titleDraft}
            on:blur={commitTitleEdit}
            on:keydown={handleTitleKeydown}
          />
        {:else}
          <h2 on:dblclick={startTitleEdit}>{dataset.style.label}</h2>
        {/if}
      </header>

      <section class="expandable-section" class:open={rightPanelSection === 'general'}>
        <button
          type="button"
          class="expandable-toggle"
          on:click={() => { rightPanelSection = rightPanelSection === 'general' ? null : 'general' }}
        >
          General
        </button>
        {#if rightPanelSection === 'general'}
          <div class="expandable-body">
            <label>
              File path
              <input
                type="text"
                value={dataset.sourcePath}
                on:input={(event) => onUpdateMetadata(dataset.id, { sourcePath: (event.target as HTMLInputElement).value })}
              />
            </label>
            <label>
              Spectrum type
              <select
                value={dataset.spectrumType}
                on:change={(event) => {
                  const raw = (event.target as HTMLSelectElement).value
                  const spectrumType = raw === 'ir' || raw === 'raman' ? raw : 'uv-vis'
                  onUpdateMetadata(dataset.id, { spectrumType })
                }}
              >
                <option value="uv-vis">UV-Vis</option>
                <option value="ir">IR</option>
                <option value="raman">Raman</option>
              </select>
            </label>
            <label>
              X units
              <input
                type="text"
                value={dataset.units.x}
                on:input={(event) => onUpdateMetadata(dataset.id, { units: { x: (event.target as HTMLInputElement).value } })}
              />
            </label>
            <label>
              Y units
              <input
                type="text"
                value={dataset.units.y}
                on:input={(event) => onUpdateMetadata(dataset.id, { units: { y: (event.target as HTMLInputElement).value } })}
              />
            </label>
          </div>
        {/if}
      </section>

      <section class="expandable-section" class:open={rightPanelSection === 'style'}>
        <button
          type="button"
          class="expandable-toggle"
          on:click={() => { rightPanelSection = rightPanelSection === 'style' ? null : 'style' }}
        >
          Style Settings
        </button>
        {#if rightPanelSection === 'style'}
          <div class="expandable-body">
            <label>
              Line Color
              <input
                type="color"
                value={dataset.style.lineColor}
                on:input={(event) => onUpdateStyle(dataset.id, { lineColor: (event.target as HTMLInputElement).value })}
              />
            </label>
            <label>
              Line Width
              <input
                type="range"
                min="1"
                max="6"
                step="0.5"
                value={dataset.style.lineWidth}
                on:input={(event) => onUpdateStyle(dataset.id, { lineWidth: Number((event.target as HTMLInputElement).value) })}
              />
            </label>
            <button type="button" class="run" on:click={() => onRerunPipeline(dataset.id)}>
              Run Pipeline in Pyodide
            </button>
          </div>
        {/if}
      </section>

      <section class="expandable-section" class:open={rightPanelSection === 'pipeline'}>
        <button
          type="button"
          class="expandable-toggle"
          on:click={() => { rightPanelSection = rightPanelSection === 'pipeline' ? null : 'pipeline' }}
        >
          Pipeline Settings
        </button>
        {#if rightPanelSection === 'pipeline'}
          <div class="expandable-body">
            {#each dataset.pipeline as transform (transform.id)}
              <div class="transform-card">
                <div class="transform-top">
                  <label class="toggle-label">
                    <input
                      type="checkbox"
                      checked={transform.enabled}
                      on:change={(event) =>
                        onTransformEnabled(dataset.id, transform.id, (event.target as HTMLInputElement).checked)}
                    />
                    <span>{transform.type}</span>
                  </label>

                  <select
                    value={transform.scope}
                    on:change={(event) =>
                      onTransformScope(
                        dataset.id,
                        transform.id,
                        (event.target as HTMLSelectElement).value as 'no' | 'individual' | 'global',
                      )}
                  >
                    <option value="no">No</option>
                    <option value="individual">Individual</option>
                    <option value="global">Global</option>
                  </select>
                </div>

                {#if transform.type === 'smoothing'}
                  <div class="transform-grid">
                    <label>
                      window
                      <input
                        type="number"
                        min="3"
                        step="2"
                        value={Number(transform.params.window_length ?? 15)}
                        on:change={(event) =>
                          onTransformParam(
                            dataset.id,
                            transform.id,
                            { window_length: Number((event.target as HTMLInputElement).value) },
                            transform.scope,
                          )}
                      />
                    </label>
                    <label>
                      polyorder
                      <input
                        type="number"
                        min="1"
                        value={Number(transform.params.polyorder ?? 2)}
                        on:change={(event) =>
                          onTransformParam(
                            dataset.id,
                            transform.id,
                            { polyorder: Number((event.target as HTMLInputElement).value) },
                            transform.scope,
                          )}
                      />
                    </label>
                  </div>
                {/if}

                {#if transform.type === 'normalization'}
                  <label>
                    mode
                    <select
                      value={String(transform.params.mode ?? 'minmax')}
                      on:change={(event) =>
                        onTransformParam(
                          dataset.id,
                          transform.id,
                          { mode: (event.target as HTMLSelectElement).value },
                          transform.scope,
                        )}
                    >
                      <option value="minmax">MinMax</option>
                      <option value="vector">Vector</option>
                      <option value="area">Area</option>
                      <option value="peak">Peak</option>
                    </select>
                  </label>
                {/if}

                {#if transform.type === 'derivative'}
                  <label>
                    order
                    <input
                      type="number"
                      min="1"
                      max="2"
                      value={Number(transform.params.order ?? 1)}
                      on:change={(event) =>
                        onTransformParam(
                          dataset.id,
                          transform.id,
                          { order: Number((event.target as HTMLInputElement).value) },
                          transform.scope,
                        )}
                    />
                  </label>
                {/if}

                {#if transform.type === 'baseline'}
                  <label>
                    poly order
                    <input
                      type="number"
                      min="1"
                      max="6"
                      value={Number(transform.params.order ?? 3)}
                      on:change={(event) =>
                        onTransformParam(
                          dataset.id,
                          transform.id,
                          { order: Number((event.target as HTMLInputElement).value) },
                          transform.scope,
                        )}
                    />
                  </label>
                {/if}

                {#if transform.type === 'crop'}
                  <div class="transform-grid">
                    <label>
                      x min
                      <input
                        type="number"
                        value={Number(transform.params.x_min ?? 200)}
                        on:change={(event) =>
                          onTransformParam(
                            dataset.id,
                            transform.id,
                            { x_min: Number((event.target as HTMLInputElement).value) },
                            transform.scope,
                          )}
                      />
                    </label>
                    <label>
                      x max
                      <input
                        type="number"
                        value={Number(transform.params.x_max ?? 800)}
                        on:change={(event) =>
                          onTransformParam(
                            dataset.id,
                            transform.id,
                            { x_max: Number((event.target as HTMLInputElement).value) },
                            transform.scope,
                          )}
                      />
                    </label>
                  </div>
                {/if}
              </div>
            {/each}
          </div>
        {/if}
      </section>
    </section>
  {:else}
    <section class="general-settings">
      <p class="general-settings-hint">
        Apply an override to every loaded spectrum at once. Select a sample to edit its individual settings.
      </p>

      <div class="general-settings-group">
        <label>
          Color palette
          <select bind:value={generalPaletteId}>
            {#each COLOR_PALETTES as palette (palette.id)}
              <option value={palette.id}>{palette.name}</option>
            {/each}
          </select>
        </label>
        <div class="palette-preview">
          {#each activeGeneralPalette.colors as color}
            <span class="palette-swatch" style={`background:${color};`}></span>
          {/each}
        </div>
        <button type="button" class="run" disabled={datasetCount === 0} on:click={() => onApplyPalette(generalPaletteId)}>
          Apply Palette To All
        </button>
      </div>

      <div class="general-settings-group">
        <label>
          Line width
          <input type="range" min="1" max="6" step="0.5" bind:value={generalLineWidth} />
        </label>
        <span class="general-settings-value">{generalLineWidth}px</span>
        <button type="button" class="run" disabled={datasetCount === 0} on:click={() => onApplyLineWidth(generalLineWidth)}>
          Apply Width To All
        </button>
      </div>

      <div class="general-settings-group">
        <label>
          Normalization mode
          <select bind:value={generalNormalizationMode}>
            <option value="minmax">MinMax</option>
            <option value="vector">Vector</option>
            <option value="area">Area</option>
            <option value="peak">Peak</option>
          </select>
        </label>
        <button
          type="button"
          class="run"
          disabled={datasetCount === 0}
          on:click={() => onApplyNormalization(generalNormalizationMode)}
        >
          Apply Normalization To All
        </button>
      </div>

      <div class="general-settings-group">
        <div class="transform-grid">
          <label>
            Smoothing window
            <input type="number" min="3" step="2" bind:value={generalSmoothingWindow} />
          </label>
          <label>
            Smoothing polyorder
            <input type="number" min="1" bind:value={generalSmoothingPolyorder} />
          </label>
        </div>
        <button
          type="button"
          class="run"
          disabled={datasetCount === 0}
          on:click={() => onApplySmoothing(generalSmoothingWindow, generalSmoothingPolyorder)}
        >
          Apply Smoothing To All
        </button>
      </div>
    </section>
  {/if}
</aside>
