<script lang="ts">
  import PeakHeatmap from '../PeakHeatmap.svelte'
  import { projectStore } from '../../state/projectStore'

  export let dataset: any
  export let peakHoverSelection: { datasetId: string; peakId: string } | null
  export let onPeakHover: (datasetId: string, peakId: string | null, fromTable: boolean) => void
  export let prominence: number
  export let minDistance: number
  export let minHeight: number | null

  let detecting = false
  let heatmapOpen = false
  let heatmapLoading = false
  let heatmapProminenceValues: number[] = []
  let heatmapDistanceValues: number[] = []
  let heatmapCounts: number[][] = []

  async function runPeakDetection(): Promise<void> {
    if (detecting) return

    detecting = true
    try {
      await projectStore.detectPeaks(dataset.id, {
        prominence,
        minDistance,
        minHeight,
      })
    } finally {
      detecting = false
    }
  }

  function buildHeatmapAxisValues(): { prominenceValues: number[]; distanceValues: number[] } {
    const values = dataset.data.ordinateModified
    const min = Math.min(...values)
    const max = Math.max(...values)
    const range = Math.max(max - min, 1e-6)

    return {
      prominenceValues: Array.from({ length: 8 }, (_, i) => {
        const t = i / 7
        return Number((range * (0.002 + t * 0.25)).toFixed(6))
      }),
      distanceValues: Array.from({ length: 8 }, (_, i) => {
        const t = i / 7
        return Math.max(1, Math.round(1 + t * 39))
      }),
    }
  }

  async function runPeakHeatmap(): Promise<void> {
    heatmapLoading = true
    const { prominenceValues, distanceValues } = buildHeatmapAxisValues()
    heatmapProminenceValues = prominenceValues
    heatmapDistanceValues = distanceValues

    try {
      const counts = await projectStore.computePeakHeatmap(dataset.id, {
        prominenceValues,
        distanceValues,
        minHeight,
      })
      heatmapCounts = counts ?? []
    } finally {
      heatmapLoading = false
    }
  }

  function toggleHeatmap(): void {
    heatmapOpen = !heatmapOpen
    if (heatmapOpen) void runPeakHeatmap()
  }

  function handleHeatmapSelect(event: CustomEvent<{ prominence: number; distance: number }>): void {
    prominence = Number(event.detail.prominence.toFixed(6))
    minDistance = Math.max(1, Math.round(event.detail.distance))
    heatmapOpen = false
  }
</script>

<div class="peak-view">
  <div class="peak-table-col">
    <h3>Peak Assignments</h3>
    {#if dataset.peaks.length === 0}
      <div class="sample-empty">No peaks yet. Run detection or click on the plot.</div>
    {:else}
      <div class="sample-table-scroll">
        <table class="sample-table" style={`--row-accent:${dataset.style.lineColor};`}>
          <thead>
            <tr>
              <th></th>
              <th>X</th>
              <th>Y</th>
              <th>Prominence</th>
              <th>Label</th>
              <th>Source</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {#each dataset.peaks as peak (peak.id)}
              <tr
                class:hovered={peakHoverSelection?.peakId === peak.id}
                class:peak-disabled={!peak.enabled}
                on:mouseenter={() => onPeakHover(dataset.id, peak.id, true)}
                on:mouseleave={() => onPeakHover(dataset.id, null, true)}
              >
                <td>
                  <input
                    type="checkbox"
                    checked={peak.enabled}
                    aria-label={`${peak.enabled ? 'Disable' : 'Enable'} peak at ${peak.x.toFixed(2)}`}
                    on:change={(event) => projectStore.setPeakEnabled(dataset.id, peak.id, (event.target as HTMLInputElement).checked)}
                  />
                </td>
                <td>{peak.x.toFixed(3)}</td>
                <td>{peak.y.toFixed(4)}</td>
                <td>{peak.prominence !== undefined ? peak.prominence.toFixed(4) : '—'}</td>
                <td>
                  <input
                    type="text"
                    class="peak-label-input"
                    value={peak.label}
                    on:input={(event) => projectStore.updatePeakLabel(dataset.id, peak.id, (event.target as HTMLInputElement).value)}
                  />
                </td>
                <td>{peak.dataOrigin === 'original' ? 'original data' : peak.source}</td>
                <td>
                  <button
                    type="button"
                    class="remove-x"
                    aria-label={`Remove peak at ${peak.x.toFixed(2)}`}
                    on:click={() => projectStore.removePeak(dataset.id, peak.id)}
                  >
                    x
                  </button>
                </td>
              </tr>
            {/each}
          </tbody>
        </table>
      </div>
    {/if}
  </div>

  <aside class="peak-settings-col">
    <div class="peak-settings-header">
      <h4>Peak Detection</h4>
      <button type="button" class="ghost" on:click={toggleHeatmap}>
        {heatmapOpen ? 'Back to Settings' : 'Parameter Heatmap'}
      </button>
    </div>

    {#if heatmapOpen}
      <p class="peak-hint">Click a cell to apply that prominence / min distance combination.</p>
      <div class="peak-heatmap-container">
        <PeakHeatmap
          prominenceValues={heatmapProminenceValues}
          distanceValues={heatmapDistanceValues}
          counts={heatmapCounts}
          currentProminence={prominence}
          currentDistance={minDistance}
          loading={heatmapLoading}
          on:select={handleHeatmapSelect}
        />
      </div>
    {:else}
      <div class="peak-settings-fields">
        <label>
          <span class="peak-field-label">
            Prominence
            <button
              type="button"
              class="info-icon"
              title="Minimum vertical distance a peak must stand above the surrounding baseline before it merges into a taller neighboring peak. Lower values detect smaller, subtler peaks."
            >?</button>
          </span>
          <input type="number" min="0" step="0.0001" bind:value={prominence} />
        </label>
        <label>
          <span class="peak-field-label">
            Min distance (points)
            <button
              type="button"
              class="info-icon"
              title="Minimum number of x-axis samples required between two neighboring peaks. Higher values suppress closely spaced duplicate peaks."
            >?</button>
          </span>
          <input type="number" min="0" step="1" bind:value={minDistance} />
        </label>
        <label>
          <span class="peak-field-label">
            Min height
            <button
              type="button"
              class="info-icon"
              title="Minimum absolute y-value (signal intensity) a point must reach to qualify as a peak. Leave empty to disable this threshold."
            >?</button>
          </span>
          <input
            type="number"
            step="0.01"
            value={minHeight ?? ''}
            placeholder="none"
            on:input={(event) => {
              const raw = (event.target as HTMLInputElement).value
              minHeight = raw.trim().length > 0 ? Number(raw) : null
            }}
          />
        </label>
      </div>
      <div class="peak-actions-row">
        <button type="button" class="run" disabled={detecting} on:click={() => void runPeakDetection()}>
          {detecting ? 'Detecting...' : 'Detect Peaks'}
        </button>
        <button
          type="button"
          class="ghost"
          disabled={dataset.peaks.length === 0}
          on:click={() => projectStore.clearPeaks(dataset.id)}
        >
          Clear Peaks
        </button>
      </div>
      <p class="peak-hint">Click on the trace in the plot above to add a peak manually.</p>
    {/if}
  </aside>
</div>
