<script lang="ts">
  import { onMount } from 'svelte'
  import { EditorState, Transaction } from '@codemirror/state'
  import { EditorView, keymap, lineNumbers, highlightActiveLine } from '@codemirror/view'
  import { defaultKeymap, history, historyKeymap } from '@codemirror/commands'
  import { python } from '@codemirror/lang-python'
  import { oneDark } from '@codemirror/theme-one-dark'
  import { projectStore } from '../../state/projectStore'

  export let active: boolean

  let editorHostEl: HTMLDivElement | null = null
  let codeMirrorView: EditorView | null = null
  let autoExecute = false
  let executing = false
  let suppressEditorSync = false
  let autoExecuteTimer: number | null = null
  let lastDebugSignature = ''

  $: currentScript = $projectStore.userScriptOverride ?? $projectStore.generatedScript

  $: {
    const signature = [
      $projectStore.syncMode,
      $projectStore.scriptSyncEnabled ? 'sync-on' : 'sync-off',
      $projectStore.userScriptOverride === null ? 'generated' : 'override',
      String($projectStore.generatedScript.length),
      String($projectStore.userScriptOverride?.length ?? 0),
    ].join('|')

    if (signature !== lastDebugSignature) {
      lastDebugSignature = signature
      console.debug('[script-debug] editor_script_source', {
        syncMode: $projectStore.syncMode,
        scriptSyncEnabled: $projectStore.scriptSyncEnabled,
        source: $projectStore.userScriptOverride === null ? 'generatedScript' : 'userScriptOverride',
        generatedLength: $projectStore.generatedScript.length,
        overrideLength: $projectStore.userScriptOverride?.length ?? 0,
      })
    }
  }

  function ensureCodeMirror(): void {
    if (!editorHostEl || codeMirrorView) return

    codeMirrorView = new EditorView({
      state: EditorState.create({
        doc: currentScript,
        extensions: [
          lineNumbers(),
          highlightActiveLine(),
          history(),
          keymap.of([...defaultKeymap, ...historyKeymap]),
          python(),
          oneDark,
          EditorView.theme({
            '&': { height: '100%' },
            '.cm-scroller': { overflow: 'auto' },
          }),
          EditorView.updateListener.of((update) => {
            if (!update.docChanged || suppressEditorSync) return

            projectStore.setScriptOverride(update.state.doc.toString())
            const userEdited = update.transactions.some((tx) => {
              const event = tx.annotation(Transaction.userEvent)
              return Boolean(event && (event.startsWith('input') || event.startsWith('delete') || event.startsWith('paste')))
            })

            if (autoExecute && userEdited) scheduleAutoExecute()
          }),
        ],
      }),
      parent: editorHostEl,
    })
  }

  onMount(() => {
    ensureCodeMirror()

    return () => {
      if (autoExecuteTimer !== null) window.clearTimeout(autoExecuteTimer)
      codeMirrorView?.destroy()
      codeMirrorView = null
    }
  })

  $: if (editorHostEl && active) ensureCodeMirror()

  $: if (codeMirrorView && currentScript !== codeMirrorView.state.doc.toString()) {
    suppressEditorSync = true
    codeMirrorView.dispatch({
      changes: {
        from: 0,
        to: codeMirrorView.state.doc.length,
        insert: currentScript,
      },
    })
    suppressEditorSync = false
  }

  function scheduleAutoExecute(): void {
    if (!autoExecute) return
    if (autoExecuteTimer !== null) window.clearTimeout(autoExecuteTimer)

    autoExecuteTimer = window.setTimeout(() => {
      void executeAutoMode()
    }, 420)
  }

  async function executeScript(): Promise<void> {
    if (executing || autoExecute || $projectStore.datasets.length === 0) return

    executing = true
    try {
      await projectStore.executeScriptForDatasets(currentScript)
    } finally {
      executing = false
    }
  }

  function handleAutoExecuteToggle(event: Event): void {
    autoExecute = (event.target as HTMLInputElement).checked
    if (autoExecute) {
      void executeAutoMode()
    } else if (autoExecuteTimer !== null) {
      window.clearTimeout(autoExecuteTimer)
      autoExecuteTimer = null
    }
  }

  async function executeAutoMode(): Promise<void> {
    if (executing || $projectStore.datasets.length === 0) return

    executing = true
    try {
      await projectStore.executeScriptForDatasets(currentScript)
    } finally {
      executing = false
    }
  }

  export function requestMeasure(): void {
    codeMirrorView?.requestMeasure()
  }
</script>

<div class="script-panel" class:hidden={!active}>
  <div class="sync-banner" data-state={$projectStore.syncMode}>
    {#if $projectStore.syncMode === 'desync_active'}
      GUI Sync Disabled. Manual edits active.
    {:else}
      GUI synchronized. Style and pipeline edits regenerate script automatically.
    {/if}
  </div>

  {#if $projectStore.workerLastError}
    <div class="script-error-banner">{$projectStore.workerLastError}</div>
  {/if}

  <div bind:this={editorHostEl} class="script-editor" aria-label="Python script editor"></div>

  <div class="script-actions">
    <label class="autoexecute-toggle">
      <input type="checkbox" checked={autoExecute} on:change={handleAutoExecuteToggle} />
      Autoexecute
    </label>
    <button type="button" class="run" disabled={autoExecute || executing} on:click={() => void executeScript()}>
      {executing ? 'Executing...' : 'Execute'}
    </button>
    <button type="button" class="ghost" on:click={() => projectStore.revertScriptToGuiState()}>
      Revert To GUI State
    </button>
  </div>
</div>
