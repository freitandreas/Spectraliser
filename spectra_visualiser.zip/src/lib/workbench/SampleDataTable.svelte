<script lang="ts">
  import { tick } from 'svelte'

  export let dataset: any
  export let hoverSelection: { datasetId: string; pointIndex: number } | null
  export let onHover: (datasetId: string, pointIndex: number | null) => void

  let tableScrollEl: HTMLDivElement | null = null

  $: if (hoverSelection?.datasetId === dataset.id) {
    void tick().then(() => {
      const row = tableScrollEl?.querySelector<HTMLTableRowElement>(
        `[data-row-index='${hoverSelection?.pointIndex}']`,
      )
      if (!row || !tableScrollEl) return

      const rowTop = row.offsetTop
      const rowBottom = rowTop + row.offsetHeight
      const visibleTop = tableScrollEl.scrollTop
      const visibleBottom = visibleTop + tableScrollEl.clientHeight

      if (rowTop < visibleTop) {
        tableScrollEl.scrollTop = rowTop - 8
      } else if (rowBottom > visibleBottom) {
        tableScrollEl.scrollTop = rowBottom - tableScrollEl.clientHeight + 8
      }
    })
  }
</script>

<div class="sample-table-wrap">
  <h3>Data Table</h3>
  <div class="sample-table-scroll" bind:this={tableScrollEl}>
    <table class="sample-table" style={`--row-accent:${dataset.style.lineColor};`}>
      <thead>
        <tr>
          <th>X</th>
          <th>Original</th>
          <th>Modified</th>
        </tr>
      </thead>
      <tbody>
        {#each dataset.data.abscissa as point, index (index)}
          <tr
            data-row-index={index}
            class:hovered={hoverSelection?.datasetId === dataset.id && hoverSelection.pointIndex === index}
            on:mouseenter={() => onHover(dataset.id, index)}
            on:mouseleave={() => onHover(dataset.id, null)}
          >
            <td>{point}</td>
            <td>{dataset.data.ordinateOriginal[index]}</td>
            <td>{dataset.data.ordinateModified[index]}</td>
          </tr>
        {/each}
      </tbody>
    </table>
  </div>
</div>
