<script lang="ts">
  export let leftPanelOpen: boolean
  export let bottomPanelOpen: boolean
  export let rightPanelOpen: boolean
  export let onToggleData: () => void
  export let onToggleScript: () => void
  export let onAnalyse: () => void
  export let onToggleSettings: () => void
  export let onExport: () => void
</script>

<header class="topbar">
  <div class="brand">Spectraliser</div>
  <nav class="menu toolbar-nav" aria-label="Main toolbar">
    <button
      type="button"
      class="toolbar-button"
      class:active={leftPanelOpen}
      aria-pressed={leftPanelOpen}
      on:click={onToggleData}
    >
      Data
    </button>
    <button
      type="button"
      class="toolbar-button"
      class:active={bottomPanelOpen}
      aria-pressed={bottomPanelOpen}
      on:click={onToggleScript}
    >
      Script
    </button>
    <button type="button" class="toolbar-button" on:click={onAnalyse}>
      Analyse
    </button>
    <button
      type="button"
      class="toolbar-button"
      class:active={rightPanelOpen}
      aria-pressed={rightPanelOpen}
      on:click={onToggleSettings}
    >
      Settings
    </button>
    <button
      type="button"
      class="toolbar-button"
      title="Use the Import Wizard, Script View, and Sample Settings to configure analysis."
    >
      About/Help
    </button>
  </nav>
  <div class="actions">
    <button type="button" class="ghost" on:click={onExport}>Export</button>
  </div>
</header>
