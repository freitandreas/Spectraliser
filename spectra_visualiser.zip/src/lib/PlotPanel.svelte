<script lang="ts">
  import { onMount } from 'svelte'
  import Plotly from 'plotly.js-dist-min'
  import type { SpectrumDataset } from '../types/project'

  export let datasets: SpectrumDataset[] = []
  export let selectedSpectrumId: string | null = null
  export let hoverSelection: { datasetId: string; pointIndex: number } | null = null
  export let peakPickingEnabled = false
  export let peakHoverSelection: { datasetId: string; peakId: string } | null = null
  export let peakZoomPeakId: string | null = null

  import { createEventDispatcher } from 'svelte'

  const dispatch = createEventDispatcher<{
    hoverpoint: { datasetId: string; pointIndex: number } | null
    peakpick: { datasetId: string; pointIndex: number }
    peakhover: { datasetId: string; peakId: string } | null
  }>()

  let container: HTMLDivElement | null = null
  let lastDatasetsRef: SpectrumDataset[] | null = null
  let lastSelectedSpectrumId: string | null = null
  let lastHoverKey = ''
  let resizeObserver: ResizeObserver | null = null

  type PlotlyTracePoint = {
    curveNumber?: number
    pointNumber?: number
  }

  type PlotTrace = {
    x: number[]
    y: number[]
    type: string
    mode: string
    name: string
    line?: {
      color: string
      width: number
    }
    opacity?: number
    hoverinfo?: string
    showlegend?: boolean
    text?: string[]
    textposition?: string
    textfont?: {
      color: string
      size: number
    }
    marker?: {
      size: number | number[]
      color: string
      symbol?: string
      line: {
        color: string
        width: number
      }
    }
  }

  type PlotlyGraphDiv = HTMLDivElement & {
    on?: (eventName: string, handler: (eventData: { points?: PlotlyTracePoint[] }) => void) => void
    removeAllListeners?: (eventName?: string) => void
  }

  let hoverHandlerAttached = false
  let preZoomRange: { x: [number, number] | null; y: [number, number] | null } | null = null

  function getPeaksDataset(): SpectrumDataset | null {
    return datasets.find((dataset) => dataset.id === selectedSpectrumId) ?? null
  }

  function buildPeakTrace(dataset: SpectrumDataset, peaks: SpectrumDataset['peaks'], hoveredId: string | null, dimmed: boolean): PlotTrace {
    return {
      x: peaks.map((peak) => peak.x),
      y: peaks.map((peak) => dataset.data.ordinateModified[peak.index] ?? peak.y),
      type: 'scatter',
      mode: 'markers+text',
      name: dimmed ? 'Peaks (original data)' : 'Peaks',
      hoverinfo: 'x+y+text',
      text: peaks.map((peak) => peak.label),
      textposition: 'top center',
      textfont: {
        color: dimmed ? 'rgba(190,190,190,0.55)' : '#f8f8f8',
        size: 11,
      },
      marker: {
        size: peaks.map((peak) => (peak.id === hoveredId ? 14 : 9)),
        symbol: 'diamond',
        color: dimmed ? 'rgba(150,150,150,0.55)' : dataset.style.lineColor,
        line: {
          color: dimmed ? 'rgba(210,210,210,0.4)' : '#f8f8f8',
          width: dimmed ? 1 : 1.5,
        },
      },
    }
  }

  function buildTraces(): PlotTrace[] {
    const traces: PlotTrace[] = datasets.map((dataset) => ({
      x: dataset.data.abscissa,
      y: dataset.data.ordinateModified,
      type: 'scatter',
      mode: 'lines',
      name: dataset.style.label,
      line: {
        color: dataset.style.lineColor,
        width: dataset.style.lineWidth,
      },
      opacity: dataset.id === selectedSpectrumId ? 1 : 0.42,
    }))

    const peaksDataset = getPeaksDataset()
    if (peaksDataset) {
      const hoveredId = peakHoverSelection?.datasetId === peaksDataset.id ? peakHoverSelection.peakId : null
      const enabledPeaks = peaksDataset.peaks.filter((peak) => peak.enabled)
      const disabledPeaks = peaksDataset.peaks.filter((peak) => !peak.enabled)
      traces.push(buildPeakTrace(peaksDataset, enabledPeaks, hoveredId, false))
      traces.push(buildPeakTrace(peaksDataset, disabledPeaks, hoveredId, true))
    }

    return traces
  }

  function traceDatasetId(curveNumber: number | undefined): string | null {
    if (curveNumber === undefined) {
      return null
    }

    return datasets[curveNumber]?.id ?? null
  }

  function attachHoverHandlers(): void {
    if (!container || hoverHandlerAttached) {
      return
    }

    const graph = container as PlotlyGraphDiv
    graph.removeAllListeners?.('plotly_hover')
    graph.removeAllListeners?.('plotly_unhover')
    graph.removeAllListeners?.('plotly_click')

    graph.on?.('plotly_hover', (eventData) => {
      const point = eventData.points?.[0]
      if (point?.curveNumber === undefined) {
        return
      }

      const peaksDataset = getPeaksDataset()
      if (peaksDataset) {
        const enabledTraceIndex = datasets.length
        const disabledTraceIndex = datasets.length + 1
        if (point.curveNumber === enabledTraceIndex || point.curveNumber === disabledTraceIndex) {
          const peaks = point.curveNumber === enabledTraceIndex
            ? peaksDataset.peaks.filter((peak) => peak.enabled)
            : peaksDataset.peaks.filter((peak) => !peak.enabled)
          const peak = point.pointNumber !== undefined ? peaks[point.pointNumber] : undefined
          if (peak) {
            dispatch('peakhover', { datasetId: peaksDataset.id, peakId: peak.id })
          }
          return
        }
      }

      const datasetId = traceDatasetId(point.curveNumber)
      const pointIndex = point.pointNumber
      if (datasetId === null || pointIndex === undefined) {
        return
      }

      dispatch('hoverpoint', { datasetId, pointIndex })
    })

    graph.on?.('plotly_unhover', () => {
      dispatch('hoverpoint', null)
      dispatch('peakhover', null)
    })

    graph.on?.('plotly_click', (eventData) => {
      if (!peakPickingEnabled) {
        return
      }

      const point = eventData.points?.[0]
      // Only main line traces (index < datasets.length) qualify; the peaks overlay trace is excluded.
      if (point?.curveNumber === undefined || point.curveNumber >= datasets.length) {
        return
      }

      const datasetId = traceDatasetId(point.curveNumber)
      const pointIndex = point.pointNumber
      if (datasetId === null || pointIndex === undefined) {
        return
      }

      dispatch('peakpick', { datasetId, pointIndex })
    })

    hoverHandlerAttached = true
  }

  async function renderPlot(): Promise<void> {
    if (!container) {
      return
    }

    const plotly = Plotly as typeof Plotly & {
      Fx?: {
        hover: (target: HTMLDivElement, points: Array<{ curveNumber: number; pointNumber: number }>) => void
        unhover: (target: HTMLDivElement) => void
      }
    }

    await plotly.react(
      container,
      buildTraces(),
      {
        autosize: true,
        uirevision: 'spectraliser-plot',
        margin: { l: 56, r: 18, t: 16, b: 48 },
        paper_bgcolor: '#141519',
        plot_bgcolor: '#141519',
        font: { color: '#d4d4d4', family: 'Segoe UI, sans-serif' },
        xaxis: {
          title: datasets[0]?.units.x ?? 'X',
          gridcolor: 'rgba(255,255,255,0.08)',
          zerolinecolor: 'rgba(255,255,255,0.12)',
        },
        yaxis: {
          title: datasets[0]?.units.y ?? 'Y',
          gridcolor: 'rgba(255,255,255,0.08)',
          zerolinecolor: 'rgba(255,255,255,0.12)',
        },
        legend: {
          bgcolor: 'rgba(20,20,22,0.6)',
          bordercolor: 'rgba(255,255,255,0.08)',
          borderwidth: 1,
        },
      },
      {
        displaylogo: false,
        responsive: true,
      },
    )

    lastDatasetsRef = datasets
    lastSelectedSpectrumId = selectedSpectrumId

    attachHoverHandlers()
    applyHoverOverlay(plotly)
  }

  function applyHoverOverlay(
    plotly: typeof Plotly & {
      Fx?: {
        hover: (target: HTMLDivElement, points: Array<{ curveNumber: number; pointNumber: number }>) => void
        unhover: (target: HTMLDivElement) => void
      }
    },
  ): void {
    if (!container) {
      return
    }

    const hoverKey = hoverSelection
      ? `${hoverSelection.datasetId}:${hoverSelection.pointIndex}`
      : 'none'

    if (hoverKey === lastHoverKey) {
      return
    }

    if (hoverSelection) {
      const traceIndex = datasets.findIndex((dataset) => dataset.id === hoverSelection.datasetId)
      if (traceIndex >= 0) {
        plotly.Fx?.hover(container, [{ curveNumber: traceIndex, pointNumber: hoverSelection.pointIndex }])
        lastHoverKey = hoverKey
      }
      return
    }

    plotly.Fx?.unhover(container)
    lastHoverKey = 'none'
  }

  function applyPeakHoverStyle(): void {
    if (!container) {
      return
    }

    const peaksDataset = getPeaksDataset()
    if (!peaksDataset) {
      return
    }

    const hoveredId = peakHoverSelection?.datasetId === peaksDataset.id ? peakHoverSelection.peakId : null
    const enabledPeaks = peaksDataset.peaks.filter((peak) => peak.enabled)
    const disabledPeaks = peaksDataset.peaks.filter((peak) => !peak.enabled)
    const plotly = Plotly as typeof Plotly & {
      restyle?: (target: HTMLDivElement, update: Record<string, unknown>, indices: number[]) => void
    }

    plotly.restyle?.(
      container,
      { 'marker.size': [enabledPeaks.map((peak) => (peak.id === hoveredId ? 14 : 9))] },
      [datasets.length],
    )
    plotly.restyle?.(
      container,
      { 'marker.size': [disabledPeaks.map((peak) => (peak.id === hoveredId ? 14 : 9))] },
      [datasets.length + 1],
    )
  }

  async function applyPeakZoom(peakId: string | null): Promise<void> {
    if (!container) {
      return
    }

    const plotly = Plotly as typeof Plotly & {
      relayout?: (target: HTMLDivElement, update: Record<string, unknown>) => Promise<unknown>
    }

    if (peakId) {
      const peaksDataset = getPeaksDataset()
      const peak = peaksDataset?.peaks.find((item) => item.id === peakId)
      if (!peaksDataset || !peak) {
        return
      }

      if (preZoomRange === null) {
        const layout = (container as unknown as { layout?: { xaxis?: { range?: number[] }; yaxis?: { range?: number[] } } }).layout
        preZoomRange = {
          x: layout?.xaxis?.range ? [layout.xaxis.range[0], layout.xaxis.range[1]] : null,
          y: layout?.yaxis?.range ? [layout.yaxis.range[0], layout.yaxis.range[1]] : null,
        }
      }

      const abscissa = peaksDataset.data.abscissa
      const span = Math.abs((abscissa[abscissa.length - 1] ?? 0) - (abscissa[0] ?? 0)) || 1
      const margin = Math.max(span * 0.03, 1)
      await plotly.relayout?.(container, {
        'xaxis.range': [peak.x - margin, peak.x + margin],
      })
      return
    }

    if (preZoomRange) {
      const restore: Record<string, unknown> = {}
      restore['xaxis.range'] = preZoomRange.x ?? undefined
      restore['xaxis.autorange'] = preZoomRange.x ? false : true
      restore['yaxis.range'] = preZoomRange.y ?? undefined
      restore['yaxis.autorange'] = preZoomRange.y ? false : true
      await plotly.relayout?.(container, restore)
      preZoomRange = null
    }
  }

  onMount(() => {
    if (container && typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => {
        const plotly = Plotly as typeof Plotly & {
          Plots?: {
            resize: (target: HTMLDivElement) => void
          }
        }

        if (container) {
          plotly.Plots?.resize(container)
        }
      })
      resizeObserver.observe(container)
    }

    void renderPlot()

    return () => {
      resizeObserver?.disconnect()
      resizeObserver = null
    }
  })

  let lastPeakHoverKey = ''
  $: if (container) {
    const peakHoverKey = peakHoverSelection ? `${peakHoverSelection.datasetId}:${peakHoverSelection.peakId}` : 'none'
    if (peakHoverKey !== lastPeakHoverKey) {
      lastPeakHoverKey = peakHoverKey
      applyPeakHoverStyle()
    }
  }

  $: if (container) {
    void applyPeakZoom(peakZoomPeakId)
  }

  $: if (container) {
    const hoverKey = hoverSelection
      ? `${hoverSelection.datasetId}:${hoverSelection.pointIndex}`
      : 'none'

    if (
      lastDatasetsRef !== datasets
      || lastSelectedSpectrumId !== selectedSpectrumId
      || hoverKey !== lastHoverKey
    ) {
      if (lastDatasetsRef !== datasets || lastSelectedSpectrumId !== selectedSpectrumId) {
        lastHoverKey = hoverKey
        void renderPlot()
      } else {
        const plotly = Plotly as typeof Plotly & {
          Fx?: {
            hover: (target: HTMLDivElement, points: Array<{ curveNumber: number; pointNumber: number }>) => void
            unhover: (target: HTMLDivElement) => void
          }
        }

        applyHoverOverlay(plotly)
      }
    }
  }
</script>

<div class="plotly-panel" bind:this={container}></div>

<style>
  .plotly-panel {
    width: 100%;
    height: 100%;
  }
</style>
