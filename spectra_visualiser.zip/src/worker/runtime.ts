// src/worker/runtime.ts

import { loadPyodide, type PyodideInterface, version as pyodideVersion } from 'pyodide'
import type { WorkerRequest, WorkerResponse } from './messages'
import { workerRequestSchema } from './messages'

const LOG_PREFIX = '[Pyodide Worker]'

function logInfo(message: string, ...data: unknown[]) {
  console.log(`${LOG_PREFIX} ${message}`, ...data)
}

function logWarn(message: string, ...data: unknown[]) {
  console.warn(`${LOG_PREFIX} ${message}`, ...data)
}

function logError(message: string, ...data: unknown[]) {
  console.error(`${LOG_PREFIX} ${message}`, ...data)
}

interface RuntimeState {
  pyodide: PyodideInterface | null
  initPromise: Promise<PyodideInterface> | null
  canceledRequests: Set<string>
}

const state: RuntimeState = {
  pyodide: null,
  initPromise: null,
  canceledRequests: new Set<string>(),
}

const RUNTIME_PACKAGES = ['numpy', 'pandas', 'scipy'] as const

function getPyodideCdnUrl(): string {
  const ver = pyodideVersion || '0.26.2'
  return `https://cdn.jsdelivr.net/pyodide/v${ver}/full/`
}

async function ensurePyodideReady(): Promise<PyodideInterface> {
  if (state.pyodide) {
    return state.pyodide
  }

  if (!state.initPromise) {
    const startTime = performance.now()
    logInfo('Initialization started...')

    state.initPromise = (async () => {
      const cdnUrl = getPyodideCdnUrl()
      logInfo(`Loading core runtime from CDN: ${cdnUrl}`)

      // 1. Initialize Pyodide with CDN as indexURL
      const pyodide = await loadPyodide({
        indexURL: cdnUrl,
      })
      logInfo(`Pyodide core v${pyodide.version} loaded successfully.`)

      // 2. Load explicit core packages from CDN
      logInfo(`Fetching and installing packages: [${RUNTIME_PACKAGES.join(', ')}]...`)
      const pkgStart = performance.now()
      await pyodide.loadPackage([...RUNTIME_PACKAGES])
      logInfo(`Packages installed in ${(performance.now() - pkgStart).toFixed(2)}ms.`)

      // 3. Load micropip for fallback package management
      logInfo('Loading micropip module...')
      await pyodide.loadPackage('micropip')

      // 4. Verify imports inside Python environment
      logInfo('Verifying Python package imports (numpy, pandas, scipy)...')
      await pyodide.runPythonAsync(`
import numpy as np
import pandas as pd
import scipy.signal as signal
`)
      const totalTime = (performance.now() - startTime).toFixed(2)
      logInfo(`Pyodide runtime fully initialized in ${totalTime}ms.`)

      state.pyodide = pyodide
      return pyodide
    })().catch((error) => {
      logError('Pyodide initialization failed:', error)
      state.initPromise = null
      state.pyodide = null
      throw new Error(`Pyodide initialization failed: ${error instanceof Error ? error.message : String(error)}`)
    })
  } else {
    logInfo('Initialization already in progress, awaiting promise...')
  }

  return state.initPromise
}

function toFloatArray(values: number[], preferFloat32: boolean): Float32Array | Float64Array {
  return preferFloat32 ? new Float32Array(values) : new Float64Array(values)
}

function maybeUpgradePrecision(values: Float32Array | Float64Array): {
  values: Float32Array | Float64Array
  precision: 'float32' | 'float64'
} {
  if (values instanceof Float64Array) {
    return { values, precision: 'float64' }
  }

  let maxAbs = 0
  for (const value of values) {
    const abs = Math.abs(value)
    if (abs > maxAbs) {
      maxAbs = abs
    }
  }

  if (maxAbs > 1e7) {
    logInfo(`Upgrading precision from float32 to float64 (max absolute value: ${maxAbs})`)
    return { values: Float64Array.from(values), precision: 'float64' }
  }

  return { values, precision: 'float32' }
}

async function executePipeline(
  request: Extract<WorkerRequest, { type: 'execute_pipeline' }>,
): Promise<WorkerResponse> {
  const startTime = performance.now()
  logInfo(`Executing pipeline for request ID: ${request.requestId} (Spectrum: ${request.spectrumId})`)

  if (state.canceledRequests.has(request.requestId)) {
    logWarn(`Pipeline request ${request.requestId} was pre-canceled before execution.`)
    return {
      type: 'cancelled',
      requestId: request.requestId,
    }
  }

  const pyodide = await ensurePyodideReady()

  const xArray = toFloatArray(request.abscissa, request.preferFloat32)
  const yArray = toFloatArray(request.ordinate, request.preferFloat32)
  const promoted = maybeUpgradePrecision(yArray)

  logInfo(`Pipeline input size: ${xArray.length} data points. Precision: ${promoted.precision}`)

  const globals = pyodide.toPy({
    abscissa: Array.from(xArray),
    ordinate_original: Array.from(promoted.values),
  })

  try {
    pyodide.setStdout({
      batched: (text) => logInfo(`[Python stdout]: ${text}`),
    })
    pyodide.setStderr({
      batched: (text) => logWarn(`[Python stderr]: ${text}`),
    })

    const code = `
import pandas as pd
import numpy as np
import scipy.signal as signal

df = pd.DataFrame({
    'abscissa': abscissa,
    'ordinate_original': ordinate_original,
})
${request.pipelineCode}
out = df['ordinate_modified'].tolist()
`
    logInfo('Checking imports for pipeline code...')
    await pyodide.loadPackagesFromImports(code)

    logInfo('Running pipeline Python script...')
    const pyStart = performance.now()
    await pyodide.runPythonAsync(code, { globals, locals: globals })
    logInfo(`Python execution completed in ${(performance.now() - pyStart).toFixed(2)}ms.`)

    const outProxy = globals.get('out')
    const ordinateModified = outProxy.toJs() as number[]
    outProxy.destroy()

    if (state.canceledRequests.has(request.requestId)) {
      logWarn(`Pipeline request ${request.requestId} was canceled during or immediately after execution.`)
      state.canceledRequests.delete(request.requestId)
      return {
        type: 'cancelled',
        requestId: request.requestId,
      }
    }

    logInfo(`Pipeline request ${request.requestId} finished successfully in ${(performance.now() - startTime).toFixed(2)}ms. Output size: ${ordinateModified.length}`)

    return {
      type: 'result',
      requestId: request.requestId,
      spectrumId: request.spectrumId,
      ordinateModified,
      precision: promoted.precision,
    }
  } catch (error) {
    logError(`Error executing pipeline request ${request.requestId}:`, error)
    throw error
  } finally {
    globals.destroy()
  }
}

async function executeScript(
  request: Extract<WorkerRequest, { type: 'execute_script' }>,
): Promise<WorkerResponse> {
  const startTime = performance.now()
  logInfo(`Executing user script for request ID: ${request.requestId} (Spectrum: ${request.spectrumId})`)

  if (state.canceledRequests.has(request.requestId)) {
    logWarn(`Script request ${request.requestId} was pre-canceled before execution.`)
    return {
      type: 'cancelled',
      requestId: request.requestId,
    }
  }

  const pyodide = await ensurePyodideReady()

  const xArray = toFloatArray(request.abscissa, request.preferFloat32)
  const yArray = toFloatArray(request.ordinate, request.preferFloat32)
  const promoted = maybeUpgradePrecision(yArray)

  logInfo(`Script input size: ${xArray.length} data points. Metadata keys: ${Object.keys(request.metadata || {}).join(', ')}`)

  const globals = pyodide.toPy({
    abscissa: Array.from(xArray),
    ordinate_original: Array.from(promoted.values),
    metadata: request.metadata,
  })

  const scriptBody = [
    'import inspect',
    'import pandas as pd',
    'import numpy as np',
    'import scipy.signal as signal',
    '',
    'df = pd.DataFrame({',
    "    'abscissa': abscissa,",
    "    'ordinate_original': ordinate_original,",
    '})',
    '',
    'meta = dict(metadata)',
    '',
    request.scriptCode,
    '',
    "if 'process_spectrum' in globals() and callable(process_spectrum):",
    '    signature = inspect.signature(process_spectrum)',
    '    param_count = len(signature.parameters)',
    '    if param_count >= 2:',
    '        result = process_spectrum(df.copy(), dict(meta))',
    '    else:',
    '        result = process_spectrum(df.copy())',
    'else:',
    '    result = df.copy()',
    '',
    'out_df = df.copy()',
    'out_meta = dict(meta)',
    '',
    'if isinstance(result, tuple):',
    '    if len(result) > 0 and result[0] is not None:',
    '        out_df = result[0]',
    '    if len(result) > 1 and isinstance(result[1], dict):',
    '        out_meta = result[1]',
    'elif isinstance(result, dict):',
    "    candidate_df = result.get('df')",
    "    candidate_meta = result.get('meta')",
    '    if candidate_df is not None:',
    '        out_df = candidate_df',
    '    if isinstance(candidate_meta, dict):',
    '        out_meta = candidate_meta',
    'elif result is not None:',
    '    out_df = result',
    '',
    'if not isinstance(out_df, pd.DataFrame):',
    '    out_df = pd.DataFrame(out_df)',
    '',
    'if not isinstance(out_meta, dict):',
    '    out_meta = dict(meta)',
    '',
    "meta_units = out_meta.get('units', {}) if isinstance(out_meta.get('units', {}), dict) else {}",
    "meta_style = out_meta.get('style', {}) if isinstance(out_meta.get('style', {}), dict) else {}",
    '',
    'out_meta = {',
    "    'name': str(out_meta.get('name', meta.get('name', ''))),",
    "    'sourcePath': str(out_meta.get('sourcePath', meta.get('sourcePath', ''))),",
    "    'spectrumType': str(out_meta.get('spectrumType', meta.get('spectrumType', 'uv-vis'))),",
    "    'units': {",
    "        'x': str(meta_units.get('x', meta.get('units', {}).get('x', ''))),",
    "        'y': str(meta_units.get('y', meta.get('units', {}).get('y', ''))),",
    '    },',
    "    'style': {",
    "        'label': str(meta_style.get('label', meta.get('style', {}).get('label', ''))),",
    "        'lineColor': str(meta_style.get('lineColor', meta.get('style', {}).get('lineColor', '#4fc1ff'))),",
    "        'lineWidth': float(meta_style.get('lineWidth', meta.get('style', {}).get('lineWidth', 2.0))),",
    "        'scatterSymbol': str(meta_style.get('scatterSymbol', meta.get('style', {}).get('scatterSymbol', 'circle'))),",
    "        'visible': bool(meta_style.get('visible', meta.get('style', {}).get('visible', True))),",
    '    },',
    '}',
    '',
    "if 'abscissa' not in out_df.columns:",
    "    out_df['abscissa'] = df['abscissa']",
    '',
    "if 'ordinate_original' not in out_df.columns:",
    "    out_df['ordinate_original'] = df['ordinate_original']",
    '',
    "if 'ordinate_modified' not in out_df.columns:",
    "    out_df['ordinate_modified'] = out_df['ordinate_original']",
    '',
    "out_abscissa = out_df['abscissa'].tolist()",
    "out_original = out_df['ordinate_original'].tolist()",
    "out = out_df['ordinate_modified'].tolist()",
  ].join('\n')

  try {
    pyodide.setStdout({
      batched: (text) => logInfo(`[Python stdout]: ${text}`),
    })
    pyodide.setStderr({
      batched: (text) => logWarn(`[Python stderr]: ${text}`),
    })

    logInfo('Checking user script for non-standard imported packages...')
    await pyodide.loadPackagesFromImports(scriptBody)

    logInfo('Executing script body in Pyodide...')
    const pyStart = performance.now()
    await pyodide.runPythonAsync(scriptBody, { globals, locals: globals })
    logInfo(`Script Python execution finished in ${(performance.now() - pyStart).toFixed(2)}ms.`)

    const abscissaProxy = globals.get('out_abscissa')
    const abscissa = abscissaProxy.toJs() as number[]
    abscissaProxy.destroy()

    const originalProxy = globals.get('out_original')
    const ordinateOriginal = originalProxy.toJs() as number[]
    originalProxy.destroy()

    const outProxy = globals.get('out')
    const ordinateModified = outProxy.toJs() as number[]
    outProxy.destroy()

    const metadataProxy = globals.get('out_meta')
    const metadata = metadataProxy.toJs() as {
      name?: string
      sourcePath?: string
      spectrumType?: string
      units?: { x: string; y: string }
      style?: {
        label: string
        lineColor: string
        lineWidth: number
        scatterSymbol: string
        visible?: boolean
      }
    }
    metadataProxy.destroy()

    if (state.canceledRequests.has(request.requestId)) {
      logWarn(`Script request ${request.requestId} was canceled after Python execution completed.`)
      state.canceledRequests.delete(request.requestId)
      return {
        type: 'cancelled',
        requestId: request.requestId,
      }
    }

    logInfo(`Script request ${request.requestId} completed successfully in ${(performance.now() - startTime).toFixed(2)}ms.`)

    return {
      type: 'result',
      requestId: request.requestId,
      spectrumId: request.spectrumId,
      abscissa,
      ordinateOriginal,
      ordinateModified,
      metadata,
      precision: promoted.precision,
    }
  } catch (error) {
    logError(`Error executing script request ${request.requestId}:`, error)
    throw error
  } finally {
    globals.destroy()
  }
}

async function detectPeaks(
  request: Extract<WorkerRequest, { type: 'detect_peaks' }>,
): Promise<WorkerResponse> {
  const startTime = performance.now()
  logInfo(`Detecting peaks for request ID: ${request.requestId} (Spectrum: ${request.spectrumId})`)

  const pyodide = await ensurePyodideReady()

  const globals = pyodide.toPy({
    abscissa: request.abscissa,
    ordinate: request.ordinate,
    prominence: request.prominence,
    min_distance: request.minDistance,
    min_height: request.minHeight,
  })

  const code = `
import numpy as np
from scipy.signal import find_peaks

x = np.asarray(abscissa, dtype=float)
y = np.asarray(ordinate, dtype=float)

find_peaks_kwargs = {}
if prominence and prominence > 0:
    find_peaks_kwargs['prominence'] = prominence
if min_distance and min_distance > 0:
    find_peaks_kwargs['distance'] = min_distance
if min_height is not None:
    find_peaks_kwargs['height'] = min_height

indices, properties = find_peaks(y, **find_peaks_kwargs)
prominences = properties.get('prominences')
if prominences is None:
    prominences = np.zeros(len(indices))

peak_index = indices.tolist()
peak_x = x[indices].tolist()
peak_y = y[indices].tolist()
peak_prominence = np.asarray(prominences).tolist()
`

  try {
    pyodide.setStdout({
      batched: (text) => logInfo(`[Python stdout]: ${text}`),
    })
    pyodide.setStderr({
      batched: (text) => logWarn(`[Python stderr]: ${text}`),
    })

    await pyodide.runPythonAsync(code, { globals, locals: globals })

    const indexProxy = globals.get('peak_index')
    const peakIndex = indexProxy.toJs() as number[]
    indexProxy.destroy()

    const xProxy = globals.get('peak_x')
    const peakX = xProxy.toJs() as number[]
    xProxy.destroy()

    const yProxy = globals.get('peak_y')
    const peakY = yProxy.toJs() as number[]
    yProxy.destroy()

    const prominenceProxy = globals.get('peak_prominence')
    const peakProminence = prominenceProxy.toJs() as number[]
    prominenceProxy.destroy()

    logInfo(`Peak detection request ${request.requestId} found ${peakIndex.length} peaks in ${(performance.now() - startTime).toFixed(2)}ms.`)

    return {
      type: 'peaks_result',
      requestId: request.requestId,
      spectrumId: request.spectrumId,
      peaks: peakIndex.map((index, position) => ({
        index,
        x: peakX[position],
        y: peakY[position],
        prominence: peakProminence[position] ?? 0,
      })),
    }
  } catch (error) {
    logError(`Error detecting peaks for request ${request.requestId}:`, error)
    throw error
  } finally {
    globals.destroy()
  }
}

async function computePeakHeatmap(
  request: Extract<WorkerRequest, { type: 'peak_heatmap' }>,
): Promise<WorkerResponse> {
  const startTime = performance.now()
  logInfo(`Computing peak heatmap for request ID: ${request.requestId} (Spectrum: ${request.spectrumId})`)

  const pyodide = await ensurePyodideReady()

  const globals = pyodide.toPy({
    abscissa: request.abscissa,
    ordinate: request.ordinate,
    prominence_values: request.prominenceValues,
    distance_values: request.distanceValues,
    min_height: request.minHeight,
  })

  const code = `
import numpy as np
from scipy.signal import find_peaks

x = np.asarray(abscissa, dtype=float)
y = np.asarray(ordinate, dtype=float)

counts = []
for prom in prominence_values:
    row = []
    for dist in distance_values:
        kwargs = {}
        if prom and prom > 0:
            kwargs['prominence'] = prom
        if dist and dist > 0:
            kwargs['distance'] = dist
        if min_height is not None:
            kwargs['height'] = min_height
        indices, _ = find_peaks(y, **kwargs)
        row.append(int(len(indices)))
    counts.append(row)
`

  try {
    pyodide.setStdout({
      batched: (text) => logInfo(`[Python stdout]: ${text}`),
    })
    pyodide.setStderr({
      batched: (text) => logWarn(`[Python stderr]: ${text}`),
    })

    await pyodide.runPythonAsync(code, { globals, locals: globals })

    const countsProxy = globals.get('counts')
    const counts = countsProxy.toJs() as number[][]
    countsProxy.destroy()

    logInfo(`Peak heatmap request ${request.requestId} computed ${counts.length}x${counts[0]?.length ?? 0} grid in ${(performance.now() - startTime).toFixed(2)}ms.`)

    return {
      type: 'peaks_heatmap_result',
      requestId: request.requestId,
      spectrumId: request.spectrumId,
      prominenceValues: request.prominenceValues,
      distanceValues: request.distanceValues,
      counts,
    }
  } catch (error) {
    logError(`Error computing peak heatmap for request ${request.requestId}:`, error)
    throw error
  } finally {
    globals.destroy()
  }
}

export async function handleWorkerRequest(requestRaw: unknown): Promise<WorkerResponse> {
  logInfo('Incoming worker message raw:', requestRaw)

  const parsed = workerRequestSchema.safeParse(requestRaw)
  if (!parsed.success) {
    logError('Worker request schema validation failed:', parsed.error.format())
    return {
      type: 'error',
      requestId: 'unknown',
      message: parsed.error.message,
    }
  }

  const request = parsed.data
  logInfo(`Processing request of type '${request.type}' (ID: ${request.requestId})`)

  if (request.type === 'init') {
    try {
      const pyodide = await ensurePyodideReady()
      logInfo(`Worker ready signal sent for request ID: ${request.requestId}`)
      return {
        type: 'ready',
        requestId: request.requestId,
        pyodideVersion: pyodide.version,
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      logError(`Initialization request failed (ID: ${request.requestId}):`, message)
      return {
        type: 'error',
        requestId: request.requestId,
        message,
      }
    }
  }

  if (request.type === 'cancel') {
    logWarn(`Registering cancellation for request ID: ${request.targetRequestId}`)
    state.canceledRequests.add(request.targetRequestId)
    return {
      type: 'cancelled',
      requestId: request.requestId,
    }
  }

  try {
    if (request.type === 'execute_script') {
      return await executeScript(request)
    }

    if (request.type === 'detect_peaks') {
      return await detectPeaks(request)
    }

    if (request.type === 'peak_heatmap') {
      return await computePeakHeatmap(request)
    }

    return await executePipeline(request)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown worker error'
    logError(`Execution failed for request ${request.requestId}:`, message)
    return {
      type: 'error',
      requestId: request.requestId,
      message,
    }
  }
}