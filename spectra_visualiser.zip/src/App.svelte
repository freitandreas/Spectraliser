<script lang="ts">
  import { tick } from 'svelte'
  import ImportWizard from './lib/ImportWizard.svelte'
  import WorkbenchHeader from './lib/workbench/WorkbenchHeader.svelte'
  import SampleExplorer from './lib/workbench/SampleExplorer.svelte'
  import WorkspaceMain from './lib/workbench/WorkspaceMain.svelte'
  import SettingsSidebar from './lib/workbench/SettingsSidebar.svelte'
  import ConfirmDialogs from './lib/workbench/ConfirmDialogs.svelte'
  import { validateImportOptions } from './services/import/importWizard'
  import { generateSelfContainedHtmlReport } from './services/export/htmlReport'
  import {
    parseDelimitedCollection,
    parseXlsxCollection,
    type ImportOptions,
  } from './services/import/parsers'
  import { projectStore } from './state/projectStore'
  import { type NormalizationMode } from './types/project'
  import {
    COLOR_PALETTES,
    makeSampleTabId,
    parseSampleTabId,
    type ResizeKind,
    type SampleSubView,
  } from './lib/workbench/workbenchUtils'

  let importOpen = false
  let importError = ''
  let wizardFiles: File[] = []

  let overwriteModalOpen = false
  let pendingGuiAction: (() => void) | null = null
  let globalScopeModalOpen = false
  let pendingGlobalAction: (() => void) | null = null

  let layoutEl: HTMLDivElement | null = null
  let workspaceMain: any = null
  let openSampleTabIds: string[] = []
  let expandedSampleId: string | null = null
  let explorerFocusDatasetId: string | null = null
  let activeWorkspaceTab: 'script_view' | string = 'script_view'
  let leftPanelWidth = 260
  let rightPanelWidth = 230
  let bottomPanelHeight = 360

  let leftPanelOpen = true
  let rightPanelOpen = true
  let bottomPanelOpen = true
  let rightPanelDatasetId: string | null = null

  let activeResize: {
    kind: ResizeKind
    startX: number
    startY: number
    startLeft: number
    startRight: number
    startBottom: number
  } | null = null

  $: plotSelectedSpectrumId = explorerFocusDatasetId
    ?? (activeWorkspaceTab === 'script_view' ? null : $projectStore.viewState.selectedSpectrumId)

  $: openedSampleTabs = openSampleTabIds
    .map((tabId) => {
      const parsed = parseSampleTabId(tabId)
      if (!parsed) return null

      const dataset = $projectStore.datasets.find((item) => item.id === parsed.datasetId)
      if (!dataset) return null

      return { tabId, dataset, subView: parsed.subView }
    })
    .filter((entry): entry is NonNullable<typeof entry> => entry !== null)

  $: visibleDatasets = $projectStore.datasets.filter((dataset) => dataset.style.visible !== false)
  $: activeSampleTabMeta = activeWorkspaceTab === 'script_view' ? null : parseSampleTabId(activeWorkspaceTab)
  $: activeSampleTabDataset = activeSampleTabMeta
    ? ($projectStore.datasets.find((dataset) => dataset.id === activeSampleTabMeta.datasetId) ?? null)
    : null
  $: activeSampleSubView = activeSampleTabMeta?.subView ?? 'data'

  $: {
    const available = new Set($projectStore.datasets.map((dataset) => dataset.id))
    const filtered = openSampleTabIds.filter((id) => {
      const parsed = parseSampleTabId(id)
      return parsed ? available.has(parsed.datasetId) : false
    })

    if (filtered.length !== openSampleTabIds.length) openSampleTabIds = filtered

    if (activeWorkspaceTab !== 'script_view') {
      const activeParsed = parseSampleTabId(activeWorkspaceTab)
      if (!activeParsed || !available.has(activeParsed.datasetId)) {
        activeWorkspaceTab = filtered[filtered.length - 1] ?? 'script_view'
      }
    }

    if (expandedSampleId && !available.has(expandedSampleId)) expandedSampleId = null
    if (explorerFocusDatasetId && !available.has(explorerFocusDatasetId)) explorerFocusDatasetId = null
    if (rightPanelDatasetId && !available.has(rightPanelDatasetId)) rightPanelDatasetId = null
  }

  $: rightPanelDataset = rightPanelDatasetId
    ? ($projectStore.datasets.find((dataset) => dataset.id === rightPanelDatasetId) ?? null)
    : null

  async function importFileWithOptions(file: File, options: ImportOptions): Promise<void> {
    const issues = validateImportOptions(options)
    if (issues.length > 0) {
      importError = issues.join(' ')
      return
    }

    const lowerName = file.name.toLowerCase()
    const collection = lowerName.endsWith('.xlsx')
      ? parseXlsxCollection(await file.arrayBuffer(), options)
      : parseDelimitedCollection(await file.text(), options)

    if (collection.series.length === 0) {
      importError = 'No numeric X/Y rows could be parsed with the current import settings.'
      return
    }

    const sourcePath = file.webkitRelativePath?.trim().length ? file.webkitRelativePath : file.name
    const baseLabel = file.name.replace(/\.[^.]+$/, '').replaceAll('_', ' ').trim() || file.name

    projectStore.importDatasets(
      collection.series.map((series, index) => ({
        name: file.name,
        sourcePath,
        label: options.hasHeader
          ? series.label
          : (collection.series.length > 1 ? `${baseLabel} ${index + 1}` : baseLabel),
        parsed: {
          abscissa: series.abscissa,
          ordinate: series.ordinate,
        },
      })),
    )
  }

  async function handleImport(event: CustomEvent<{ files: File[]; options: ImportOptions }>): Promise<void> {
    importError = ''
    const { files, options } = event.detail

    try {
      for (const file of files) await importFileWithOptions(file, options)
      importOpen = false
      wizardFiles = []
    } catch (error) {
      importError = error instanceof Error ? error.message : 'Import failed.'
    }
  }

  function openWizardWithFiles(files: File[]): void {
    if (files.length === 0) return
    wizardFiles = files
    importOpen = true
  }

  function downloadReport(): void {
    const state = projectStore.snapshot()
    const html = generateSelfContainedHtmlReport(state)
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = `${state.projectName.replace(/\s+/g, '_')}.html`
    anchor.click()
    URL.revokeObjectURL(url)
  }

  function queueGuiAction(action: () => void): void {
    if ($projectStore.syncMode === 'desync_active') {
      pendingGuiAction = action
      overwriteModalOpen = true
      return
    }
    action()
  }

  function renameDataset(datasetId: string, label: string): void {
    queueGuiAction(() => projectStore.updateStyle(datasetId, { label }))
  }

  function updateDatasetStyle(datasetId: string, patch: Record<string, unknown>): void {
    queueGuiAction(() => projectStore.updateStyle(datasetId, patch as any))
  }

  function updateDatasetMetadata(datasetId: string, patch: Record<string, unknown>): void {
    queueGuiAction(() => projectStore.updateDatasetMetadata(datasetId, patch as any))
  }

  function confirmOverwriteAndApply(): void {
    if (!pendingGuiAction) {
      overwriteModalOpen = false
      return
    }

    projectStore.confirmOverwriteForGuiEdits()
    pendingGuiAction()
    pendingGuiAction = null
    overwriteModalOpen = false
  }

  function cancelOverwrite(): void {
    pendingGuiAction = null
    overwriteModalOpen = false
  }

  function updateTransformEnabled(datasetId: string, transformId: string, enabled: boolean): void {
    queueGuiAction(() => projectStore.updateTransform(datasetId, transformId, { enabled }))
  }

  function updateTransformScope(
    datasetId: string,
    transformId: string,
    scope: 'no' | 'individual' | 'global',
  ): void {
    if (scope === 'global') {
      pendingGlobalAction = () => {
        queueGuiAction(() => projectStore.updateTransformGlobal(transformId, { scope: 'global' }))
      }
      globalScopeModalOpen = true
      return
    }

    queueGuiAction(() => projectStore.updateTransform(datasetId, transformId, { scope }))
  }

  function updateTransformParam(
    datasetId: string,
    transformId: string,
    params: Record<string, number | string | boolean>,
    currentScope: 'no' | 'individual' | 'global',
  ): void {
    queueGuiAction(() => {
      if (currentScope === 'global') {
        projectStore.updateTransformGlobal(transformId, { params })
      } else {
        projectStore.updateTransform(datasetId, transformId, { params })
      }
    })
  }

  function confirmGlobalScopeApply(): void {
    const action = pendingGlobalAction
    pendingGlobalAction = null
    globalScopeModalOpen = false
    action?.()
  }

  function cancelGlobalScopeApply(): void {
    pendingGlobalAction = null
    globalScopeModalOpen = false
  }

  function requestGlobalApply(action: () => void): void {
    pendingGlobalAction = () => queueGuiAction(action)
    globalScopeModalOpen = true
  }

  function applyGlobalPalette(paletteId: string): void {
    const palette = COLOR_PALETTES.find((entry) => entry.id === paletteId)
    if (!palette || palette.colors.length === 0) return

    const datasets = $projectStore.datasets
    requestGlobalApply(() => {
      datasets.forEach((dataset, index) => {
        projectStore.updateStyle(dataset.id, { lineColor: palette.colors[index % palette.colors.length] })
      })
    })
  }

  function applyGlobalLineWidth(width: number): void {
    const datasets = $projectStore.datasets
    requestGlobalApply(() => {
      datasets.forEach((dataset) => projectStore.updateStyle(dataset.id, { lineWidth: width }))
    })
  }

  function applyGlobalNormalization(mode: NormalizationMode): void {
    requestGlobalApply(() => {
      projectStore.updateTransformGlobal('normalize-1', { scope: 'global', params: { mode } })
    })
  }

  function applyGlobalSmoothing(windowLength: number, polyorder: number): void {
    requestGlobalApply(() => {
      projectStore.updateTransformGlobal('smooth-1', {
        scope: 'global',
        params: { window_length: windowLength, polyorder },
      })
    })
  }

  function clearFileSelection(): void {
    explorerFocusDatasetId = null
    rightPanelDatasetId = null
  }

  function removeDatasetFromExplorer(datasetId: string): void {
    const dataset = $projectStore.datasets.find((item) => item.id === datasetId)
    if (dataset && confirm(`Remove ${dataset.style.label}?`)) projectStore.removeDataset(dataset.id)
  }

  function toggleSampleExpanded(datasetId: string): void {
    expandedSampleId = expandedSampleId === datasetId ? null : datasetId
  }

  function focusSampleInExplorer(datasetId: string): void {
    toggleSampleExpanded(datasetId)
    explorerFocusDatasetId = datasetId
    rightPanelDatasetId = datasetId
    rightPanelOpen = true
    workspaceMain?.clearHoverSelection()
    projectStore.selectDataset(datasetId)
  }

  function toggleSampleVisibility(datasetId: string): void {
    const dataset = $projectStore.datasets.find((item) => item.id === datasetId)
    if (!dataset) return

    const currentlyVisible = dataset.style.visible !== false
    queueGuiAction(() => projectStore.updateStyle(datasetId, { visible: !currentlyVisible }))
  }

  function activateScriptTab(): void {
    activeWorkspaceTab = 'script_view'
    explorerFocusDatasetId = null
    projectStore.setActiveTab('script_view')
  }

  function openSampleSubTab(datasetId: string, subView: SampleSubView): void {
    const tabId = makeSampleTabId(datasetId, subView)
    if (!openSampleTabIds.includes(tabId)) openSampleTabIds = [...openSampleTabIds, tabId]

    activeWorkspaceTab = tabId
    explorerFocusDatasetId = null
    rightPanelDatasetId = datasetId
    rightPanelOpen = true
    bottomPanelOpen = true
    projectStore.selectDataset(datasetId)
    projectStore.setActiveTab(subView === 'peaks' ? 'peak_table' : 'sample_view')
  }

  function startResize(kind: ResizeKind, event: MouseEvent): void {
    event.preventDefault()
    activeResize = {
      kind,
      startX: event.clientX,
      startY: event.clientY,
      startLeft: leftPanelWidth,
      startRight: rightPanelWidth,
      startBottom: bottomPanelHeight,
    }

    document.body.style.userSelect = 'none'
    document.body.style.cursor = kind === 'bottom' ? 'row-resize' : 'col-resize'
    window.addEventListener('mousemove', handleResizeMove)
    window.addEventListener('mouseup', stopResize)
  }

  function handleResizeMove(event: MouseEvent): void {
    if (!activeResize || !layoutEl) return

    if (activeResize.kind === 'left') {
      const dx = event.clientX - activeResize.startX
      const maxLeft = Math.max(220, layoutEl.clientWidth - rightPanelWidth - 460)
      leftPanelWidth = Math.min(maxLeft, Math.max(180, activeResize.startLeft + dx))
      workspaceMain?.requestScriptMeasure()
      return
    }

    if (activeResize.kind === 'right') {
      const dx = event.clientX - activeResize.startX
      const maxRight = Math.max(180, layoutEl.clientWidth - leftPanelWidth - 500)
      rightPanelWidth = Math.min(maxRight, Math.max(170, activeResize.startRight - dx))
      workspaceMain?.requestScriptMeasure()
      return
    }

    const mainHeight = workspaceMain?.getMainHeight() ?? 0
    if (mainHeight <= 0) return

    const dy = event.clientY - activeResize.startY
    const maxBottom = Math.max(220, mainHeight - 220)
    bottomPanelHeight = Math.min(maxBottom, Math.max(180, activeResize.startBottom - dy))
    workspaceMain?.requestScriptMeasure()
  }

  function stopResize(): void {
    activeResize = null
    document.body.style.userSelect = ''
    document.body.style.cursor = ''
    window.removeEventListener('mousemove', handleResizeMove)
    window.removeEventListener('mouseup', stopResize)
  }

  function closeSampleTab(tabId: string): void {
    const nextTabs = openSampleTabIds.filter((id) => id !== tabId)
    const wasActive = activeWorkspaceTab === tabId
    openSampleTabIds = nextTabs
    if (!wasActive) return

    const fallbackId = nextTabs[nextTabs.length - 1]
    if (!fallbackId) {
      activateScriptTab()
      void tick().then(() => workspaceMain?.requestScriptMeasure())
      return
    }

    activeWorkspaceTab = fallbackId
    const parsed = parseSampleTabId(fallbackId)
    if (parsed) {
      projectStore.selectDataset(parsed.datasetId)
      projectStore.setActiveTab(parsed.subView === 'peaks' ? 'peak_table' : 'sample_view')
    }
  }
</script>

<div class="workbench">
  <WorkbenchHeader
    {leftPanelOpen}
    {bottomPanelOpen}
    {rightPanelOpen}
    onToggleData={() => { leftPanelOpen = !leftPanelOpen }}
    onToggleScript={() => {
      bottomPanelOpen = !bottomPanelOpen
      if (bottomPanelOpen) {
        activateScriptTab()
        void tick().then(() => workspaceMain?.requestScriptMeasure())
      }
    }}
    onAnalyse={() => {
      const selectedId = $projectStore.viewState.selectedSpectrumId ?? $projectStore.datasets[0]?.id
      if (selectedId) openSampleSubTab(selectedId, 'data')
    }}
    onToggleSettings={() => {
      rightPanelOpen = !rightPanelOpen
      if (rightPanelOpen) rightPanelDatasetId = null
    }}
    onExport={downloadReport}
  />

  <div
    class="layout"
    bind:this={layoutEl}
    style={`grid-template-columns:${leftPanelOpen ? leftPanelWidth : 0}px ${leftPanelOpen ? 6 : 0}px minmax(0, 1fr) ${rightPanelOpen ? 6 : 0}px ${rightPanelOpen ? rightPanelWidth : 0}px;`}
  >
    <SampleExplorer
      open={leftPanelOpen}
      datasets={$projectStore.datasets}
      {expandedSampleId}
      selectedDatasetId={explorerFocusDatasetId ?? $projectStore.viewState.selectedSpectrumId}
      onClose={() => { leftPanelOpen = false }}
      onFiles={openWizardWithFiles}
      onFocus={focusSampleInExplorer}
      onToggleVisibility={toggleSampleVisibility}
      onRemove={removeDatasetFromExplorer}
      onOpenSubTab={openSampleSubTab}
    />

    <button
      type="button"
      class="resizer-col"
      class:hidden={!leftPanelOpen}
      aria-label="Resize left panel"
      on:mousedown={(event) => startResize('left', event)}
    ></button>

    <WorkspaceMain
      bind:this={workspaceMain}
      {visibleDatasets}
      selectedSpectrumId={plotSelectedSpectrumId}
      {activeWorkspaceTab}
      {activeSampleSubView}
      {activeSampleTabDataset}
      {openedSampleTabs}
      {bottomPanelOpen}
      {bottomPanelHeight}
      onClearFileSelection={clearFileSelection}
      onStartBottomResize={(event) => startResize('bottom', event)}
      onOpenSubTab={openSampleSubTab}
      onActivateScript={activateScriptTab}
      onCloseTab={closeSampleTab}
      onCloseBottomPanel={() => { bottomPanelOpen = false }}
    />

    <button
      type="button"
      class="resizer-col"
      class:hidden={!rightPanelOpen}
      aria-label="Resize right panel"
      on:mousedown={(event) => startResize('right', event)}
    ></button>

    <SettingsSidebar
      open={rightPanelOpen}
      dataset={rightPanelDataset}
      datasetCount={$projectStore.datasets.length}
      onClose={() => { rightPanelOpen = false }}
      onRename={renameDataset}
      onUpdateStyle={updateDatasetStyle}
      onUpdateMetadata={updateDatasetMetadata}
      onRerunPipeline={(datasetId) => projectStore.rerunPipeline(datasetId)}
      onTransformEnabled={updateTransformEnabled}
      onTransformScope={updateTransformScope}
      onTransformParam={updateTransformParam}
      onApplyPalette={applyGlobalPalette}
      onApplyLineWidth={applyGlobalLineWidth}
      onApplyNormalization={applyGlobalNormalization}
      onApplySmoothing={applyGlobalSmoothing}
    />
  </div>

  {#if importError}
    <div class="toast toast-error">{importError}</div>
  {/if}
</div>

<ImportWizard
  open={importOpen}
  files={wizardFiles}
  on:close={() => {
    importOpen = false
    wizardFiles = []
  }}
  on:import={handleImport}
/>

<ConfirmDialogs
  overwriteOpen={overwriteModalOpen}
  globalScopeOpen={globalScopeModalOpen}
  datasetCount={$projectStore.datasets.length}
  onCancelOverwrite={cancelOverwrite}
  onConfirmOverwrite={confirmOverwriteAndApply}
  onCancelGlobal={cancelGlobalScopeApply}
  onConfirmGlobal={confirmGlobalScopeApply}
/>
