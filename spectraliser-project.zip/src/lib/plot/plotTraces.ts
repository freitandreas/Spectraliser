import { peakModeFor, type SpectrumDataset } from '../../types/project'
import type { PlotSeriesMode } from '../../services/startupPreferences'
import { formatUnit } from '../../services/spectrumPresets'

export interface PlotTrace {
  x: number[]
  y: number[]
  type: string
  mode: string
  name: string
  line?: { color: string; width: number }
  opacity?: number
  hoverinfo?: string
  showlegend?: boolean
  marker?: {
    size: number | number[]
    color: string
    symbol?: string
    line: { color: string; width: number }
  }
  hovertemplate?: string
}

export function unitSuffix(unit: string): string {
  const normalized = unit.trim()
  return normalized.length > 0 ? ` ${formatUnit(normalized)}` : ''
}

export function buildPeakTrace(
  dataset: SpectrumDataset,
  peaks: SpectrumDataset['peaks'],
  hoveredId: string | null,
): PlotTrace {
  const xUnit = unitSuffix(dataset.units.x)
  const yUnit = unitSuffix(dataset.units.y)

  return {
    x: peaks.map((peak) => peak.x),
    y: peaks.map((peak) => dataset.data.ordinateModified[peak.index] ?? peak.y),
    type: 'scatter',
    mode: 'markers',
    name: 'Peaks',
    hoverinfo: 'x+y+text',
    marker: {
      size: peaks.map((peak) => (peak.id === hoveredId ? 14 : 9)),
      symbol: 'diamond',
      color: dataset.style.lineColor,
      line: { color: '#f8f8f8', width: 1.5 },
    },
    hovertemplate: `%{x:.6g}${xUnit}<br>%{y:.6g}${yUnit}<extra>${dataset.style.label} peak</extra>`,
  }
}

export function buildLineTraces(
  datasets: SpectrumDataset[],
  selectedSpectrumId: string | null,
  highlightedDatasetId: string | null,
  lineWidthOverride?: number,
  seriesMode: PlotSeriesMode = 'lines',
  uniform = false,
): PlotTrace[] {
  return datasets.map((dataset) => {
    const emphasised = uniform || dataset.id === selectedSpectrumId || dataset.id === highlightedDatasetId

    return {
      x: dataset.data.abscissa,
      y: dataset.data.ordinateModified,
      type: 'scatter',
      mode: seriesMode,
      name: dataset.style.label,
      line: {
        color: dataset.style.lineColor,
        width: dataset.id === highlightedDatasetId
          ? (lineWidthOverride ?? dataset.style.lineWidth) + 1
          : lineWidthOverride ?? dataset.style.lineWidth,
      },
      marker: {
        size: 4,
        color: dataset.style.lineColor,
        symbol: dataset.style.scatterSymbol,
        line: { color: dataset.style.lineColor, width: 0 },
      },
      opacity: emphasised ? 1 : 0.42,
      hovertemplate: `%{x:.6g}${unitSuffix(dataset.units.x)}<br>%{y:.6g}${unitSuffix(dataset.units.y)}<extra>${dataset.style.label}</extra>`,
    }
  })
}

// Scatter text ignores rotation in this Plotly build, so labels are drawn as rotated annotations.
export function buildPeakAnnotations(dataset: SpectrumDataset | null): Record<string, unknown>[] {
  if (!dataset) {
    return []
  }

  const minima = peakModeFor(dataset.spectrumType, dataset.peakDetection?.mode) === 'minima'

  return dataset.peaks.map((peak) => ({
    x: peak.x,
    y: dataset.data.ordinateModified[peak.index] ?? peak.y,
    text: peak.x.toFixed(2),
    textangle: -90,
    showarrow: false,
    xanchor: 'center',
    yanchor: minima ? 'top' : 'bottom',
    yshift: minima ? -10 : 10,
    font: { color: '#f8f8f8', size: 11 },
  }))
}
